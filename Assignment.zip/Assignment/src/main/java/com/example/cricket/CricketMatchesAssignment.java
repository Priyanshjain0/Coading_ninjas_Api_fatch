package com.example.cricket;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import javax.net.ssl.SSLContext;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

public class CricketMatchesAssignment {

    public static void main(String[] args) {
        try {
            String apiUrl = "https://api.cuvora.com/car/partner/cricket-data";
            String apiKey = "test-creds@2320";

            // Set up SSL context to trust all certificates
            SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial(new TrustAllStrategy())
                .build();

            SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            CloseableHttpClient httpClient = HttpClients.custom()
                .setSSLSocketFactory(socketFactory)
                .build();

            HttpGet request = new HttpGet();
            request.setURI(new URI(apiUrl));
            request.addHeader("apiKey", apiKey);

            HttpResponse response = httpClient.execute(request);
            BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String inputLine;
            StringBuffer content = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();

           
            System.out.println("Raw JSON response: " + content.toString());

           
            JSONObject jsonResponse = new JSONObject(content.toString());

            // Assuming the array of matches is inside a field called "matches"
            JSONArray matches = jsonResponse.getJSONArray("matches");

            // Variables to store the results
            int highestScore = 0;
            String highestScoreTeam = "";
            int matchesWith300PlusScore = 0;

            // Iterate through each match and compute the required results
            for (int i = 0; i < matches.length(); i++) {
                JSONObject match = matches.getJSONObject(i);
                String t1 = match.getString("t1");
                String t2 = match.getString("t2");
                String t1s = match.optString("t1s", "0/0").split("/")[0];
                String t2s = match.optString("t2s", "0/0").split("/")[0];

                int t1Score = Integer.parseInt(t1s.split("/")[0]);
                int t2Score = Integer.parseInt(t2s.split("/")[0]);

                // Check for highest score
                if (t1Score > highestScore) {
                    highestScore = t1Score;
                    highestScoreTeam = t1;
                }
                if (t2Score > highestScore) {
                    highestScore = t2Score;
                    highestScoreTeam = t2;
                }

                // Check for matches with 300+ total score
                if ((t1Score + t2Score) > 300) {
                    matchesWith300PlusScore++;
                }
            }

            // Printing and returning the results
            System.out.println("Highest Score in one innings: " + highestScore + " by " + highestScoreTeam);
            System.out.println("Number of matches with total 300+ score: " + matchesWith300PlusScore);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
